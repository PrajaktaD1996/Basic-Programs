# C_programs
The repository contains basic C programs.<br>
*prerequisite :<br>
1. Check the GCC version using command line: gcc --version.<br>
   
*To create a new file using Vim editor(Example):<br>
1.vim hello.c //new file in vim editor<br>
2.gcc hello.c -o hello_out //file compilation<br>
3../hello_out //run file<br>

